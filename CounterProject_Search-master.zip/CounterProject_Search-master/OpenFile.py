from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QFileDialog, QMainWindow, QApplication, QPushButton, QLabel, QTextBrowser
import sys
from PyQt5 import uic

class UI(QMainWindow):
    def __init__(self):
        super(UI, self).__init__()

        uic.loadUi("CounterProject_Search.ui",self)

        self.ImportSearch_PushButton.clicked.connect(self.clicker_import)
        self.ExportSearch_PushButton.clicked.connect(self.clicker_export)

        self.show()

    def clicker_import(self):
        file_name = QFileDialog.getOpenFileName(self, "Open File", "", "JSON file (*.dat)")

    def clicker_export(self):
        file_name = QFileDialog.getSaveFileName(self, "Save File", "", "JSON file (*.dat)")



app = QApplication(sys.argv)
UIWindow = UI()
app.exec_()